package br.com.alanryan.spring_maven_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMavenDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
