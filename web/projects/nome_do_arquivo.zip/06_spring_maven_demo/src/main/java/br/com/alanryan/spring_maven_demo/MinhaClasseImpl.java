package br.com.alanryan.spring_maven_demo;

public class MinhaClasseImpl extends MinhaClasse{

    public MinhaClasseImpl(String atributo) {
        super(atributo);
    }
    
}
