package br.com.alanryan.spring_maven_demo;

public record Saudacao (
    String mensagem,
    String nome) {

}
